local M = {type = "auxiliary"}
local prefix = "/settings/njk_corsa_b_fuel_"
local ready, previous, elapsed = false, nil, 0

-- Fuel can fall or rise. Select the newest valid snapshot by revision.
local function latest()
  local best = {revision = 0}
  for slot = 0, 1 do
    local path = prefix .. slot .. ".json"
    local row = FS:fileExists(path) and jsonReadFile(path)
    if row and type(row.revision) == "number" and row.revision > best.revision
       and type(row.litres) == "number" and row.litres >= 0 and row.litres <= 46 then
      best = row
    end
  end
  return best
end

local function reset()
  ready, previous, elapsed = false, nil, 0
end

local function updateGFX(dt)
  local tank = energyStorage.getStorage("mainTank")
  if not tank or tank.energyCapacity <= 0 then return end
  if not ready then
    local row = latest()
    if row.litres ~= nil then tank:setRemainingVolume(row.litres) end
    previous, ready = row.litres, true
  end
  local litres = math.max(0, math.min(tank.capacity, tank.storedEnergy / tank.energyCapacity * tank.capacity))
  if litres == previous then return end
  elapsed = elapsed + dt
  if previous ~= nil and litres > 0 and litres < previous and elapsed < 1 then return end
  local revision = latest().revision + 1
  local path = prefix .. (revision % 2) .. ".json"
  jsonWriteFile(path, {revision = revision, litres = litres}, false)
  local check = jsonReadFile(path)
  if check and check.revision == revision then previous = litres end
  elapsed = 0
end

M.init = reset
M.reset = reset
M.updateGFX = updateGFX
return M
