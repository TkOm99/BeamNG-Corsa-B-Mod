local M={type='auxiliary',defaultOrder=80}
local zones={}
local elapsed,accumulator=0,0
local function reset()
 elapsed=0;accumulator=0
 for _,z in ipairs(zones) do z.state=0;z.pending=0;electrics.values['njkDamage_'..z.name]=0 end
end
local function init(data)
 zones={}
 local byName={}
 for id,n in pairs(v.data.nodes) do if n.name then byName[n.name]=n.cid or id end end
 for _,cfg in ipairs(data.zones or {}) do
  local z={name=cfg.name,kind=cfg.kind,crack=cfg.crackThreshold,shatter=cfg.shatterThreshold,pairs={}}
  local ids={}
  for _,name in ipairs(cfg.nodes) do if byName[name] then ids[#ids+1]=byName[name] end end
  z.soundNode=ids[1]
  -- Distances within the pane's frame ignore vehicle motion and door opening.
  for i=1,#ids do for j=i+1,#ids do
   local length=(obj:getNodePosition(ids[i])-obj:getNodePosition(ids[j])):length()
   if length>.08 then z.pairs[#z.pairs+1]={a=ids[i],b=ids[j],length=length} end
  end end
  zones[#zones+1]=z
 end
 reset()
end
local function updateGFX(dt)
 elapsed=elapsed+dt;accumulator=accumulator+dt
 if elapsed<1 or accumulator<.05 then return end
 local step=accumulator;accumulator=0
 for _,z in ipairs(zones) do
  local cracked,shattered=0,0
  for _,p in ipairs(z.pairs) do
   local length=(obj:getNodePosition(p.a)-obj:getNodePosition(p.b)):length()
   local strain=math.abs(length-p.length)/p.length
   if strain>z.crack then cracked=cracked+1 end
   if strain>z.shatter then shattered=shattered+1 end
  end
  local nextState=shattered>=2 and 1 or (cracked>=2 and .25 or 0)
  if nextState>z.state then
   z.pending=z.pending+step
   if z.pending>=.025 then
    if z.state==0 and z.soundNode then
     local event=z.kind=='laminated' and 'event:>Destruction>Vehicle>Glass>impact_glass_windscreen_01' or 'event:>Destruction>Vehicle>Glass>glassbreaksound6'
     sounds.playSoundOnceFollowNode(event,z.soundNode,.45)
    end
    z.state=nextState;z.pending=0
   end
  else z.pending=0 end
  electrics.values['njkDamage_'..z.name]=z.state
 end
end
M.init=init;M.reset=reset;M.updateGFX=updateGFX
return M
