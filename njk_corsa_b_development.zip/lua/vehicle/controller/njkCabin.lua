local M = {type = "auxiliary"}
local target, position, timer = {}, {}, 0
local panes = {}
local masks = {63,6,91,79,102,109,125,7,127,111}
local function digits(field, value)
  for place = 1,0,-1 do
    local mask = value and masks[value % 10 + 1] or 64
    if value then value = math.floor(value/10) end
    for bit = 0,6 do
      electrics.values[string.format("njkTid_%s_%d_%d",field,place,bit)] = math.floor(mask/2^bit)%2
    end
  end
end
local function clock(minutes,day,month,year)
  digits("hour",minutes and math.floor(minutes/60))
  digits("minute",minutes and minutes%60)
  digits("day",day)
  digits("month",month)
  digits("year",year and year%100)
end
local gearLever, fore, lateral
local handbrakePosition
local handbrakeSoundNode=0
local movingTargets={}
local function moveTarget(key,phase,steps,radius)
  local step=math.floor(phase*steps+.5)
  if movingTargets[key]==step then return end
  movingTargets[key]=step
  local target=step==0 and key or key..'_pos'..step
  obj:queueGameEngineLua(string.format([[
    local v=be:getObjectByID(%d)
    local data=v and core_vehicle_manager.getVehicleData(v:getID())
    if data then
      for _,row in pairs(data.vdata.triggers or {}) do
        local id=row.name or row.id
        if type(id)=='string' and (id==%q or id:find(%q,1,true)==1) then
          v:getTrigger(row.cid):setSphereSize(id==%q and %.5f or .00001)
        end
      end
    end]],objectId,key,key..'_pos',target,radius))
end
local flaps
local wiperMode, frontPhase, rearPhase, hazardPress, turnLever, wiperLever
local function reset()
  movingTargets={}
  flaps={glovebox={signal='njkGlovebox',position=0,target=0},fuel={signal='njkFuelFlap',position=0,target=0}}
  for _,side in ipairs({'L','R'}) do flaps['visor'..side]={signal='njkVisor'..side,position=0,target=0} end
  wiperMode, frontPhase, rearPhase, hazardPress, turnLever, wiperLever=0,0,0,0,0,0
  handbrakePosition=nil
  for id,n in pairs(v.data.nodes or {}) do
    if n.name=="cb_ref" then handbrakeSoundNode=n.cid or id end
  end
  gearLever, fore, lateral=nil,0,0
  target={L=0,R=0}; position={L=0,R=0}; timer=0
  panes={}
  for _,prop in pairs(v.data.props or {}) do
    if prop.func=="njkGearLever" then gearLever=prop end
    local side=prop.func:match("^njkWindow([LR])$")
    if side then panes[side]=prop end
  end
  clock(nil,nil,nil,nil)
end
local function cycle(side)
  target[side]=(target[side]+1)%3
end
local function advanceWiper(phase, running, frequency, dt)
  if running then return (phase+frequency*dt)%1 end
  if phase==0 then return 0 end
  phase=phase+frequency*dt
  return phase>=1 and 0 or phase
end
local function cycleWipers()
  wiperMode=(wiperMode+1)%3
end
local function pressHazard()
  hazardPress=.20
  electrics.toggle_warn_signal()
end
local function updateGFX(dt)
  local e=electrics.values
  for _,flap in pairs(flaps) do
    local delta=flap.target-flap.position
    flap.position=flap.position+math.max(-2.4*dt,math.min(2.4*dt,delta))
    e[flap.signal]=flap.position^2*(3-2*flap.position)
  end
  frontPhase=advanceWiper(frontPhase,wiperMode>0,wiperMode==2 and 1.1 or .62,dt)
  rearPhase=advanceWiper(rearPhase,wiperMode==2,.44,dt)
  e.njkWipeLeft=(1-math.cos(frontPhase*2*math.pi))*.5
  e.njkWipeRight=e.njkWipeLeft
  e.njkWipeRear=(1-math.cos(rearPhase*2*math.pi))*.5
  wiperLever=wiperLever+math.max(-10*dt,math.min(10*dt,wiperMode-wiperLever))
  e.njkWiperStalk=wiperLever
  moveTarget('njk_glovebox',e.njkGlovebox,8,.038)
  moveTarget('njk_fuel_flap',e.njkFuelFlap,6,.0485)
  moveTarget('njk_wiper',wiperLever*.5,2,.025)
  local turn=(e.signal_left_input==1 and 1 or 0)-(e.signal_right_input==1 and 1 or 0)
  turnLever=turnLever+math.max(-14*dt,math.min(14*dt,turn-turnLever))
  e.njkTurnStalk=turnLever
  hazardPress=math.max(0,hazardPress-dt)
  e.njkHazardPush=math.max(0,1-math.abs(hazardPress-.10)/.10)
  local brakeTarget=math.max(0,math.min(1,e.parkingbrake or 0))
  local step=dt*2.5
  handbrakePosition=handbrakePosition or brakeTarget
  local previousPosition=handbrakePosition
  handbrakePosition=handbrakePosition+math.max(-step,math.min(step,brakeTarget-handbrakePosition))
  -- Five ratchet teeth over the animated pull; silent while held or lowered.
  if brakeTarget>previousPosition and
      math.floor(handbrakePosition*5+0.00001)>math.floor(previousPosition*5+0.00001) then
    sounds.playSoundOnceFollowNode('event:>Vehicle>Interior>Handbrake_Lever>Lever_01_Lock',handbrakeSoundNode,.65,1.15)
  end
  e.njkHandbrake=handbrakePosition
  moveTarget('njk_handbrake',handbrakePosition,4,.050)
  if gearLever then
    local gear=e.gearIndex or 0
    local targetX=({[1]=12,[3]=12,[5]=12,[2]=-12,[4]=-12,[-1]=-12})[gear] or 0
    local targetY=({[1]=11,[2]=11,[5]=-11,[-1]=-11})[gear] or 0
    local step=dt*140
    fore=fore+math.max(-step,math.min(step,targetX-fore))
    lateral=lateral+math.max(-step,math.min(step,targetY-lateral))
    gearLever.rotation.x=math.rad(fore)
    gearLever.rotation.y=math.rad(lateral)
    e.njkGearLever=1
  end
  local powered=(e.ignitionLevel or 0)>=2
  local stopped=e.engineRunning~=1 and e.engineRunning~=true
  local engine=powertrain.getDevice("mainEngine")
  local debugData=engine and engine.thermals and engine.thermals.debugData
  local thermal=debugData and debugData.engineThermalData
  local poorLubrication=thermal and (thermal.oilLubricationCoef or 1)<.8
  e.njkOilWarning=powered and (stopped or poorLubrication) and 1 or 0
  e.njkChargeWarning=powered and stopped and 1 or 0
  e.njkAbsLamp=powered and (stopped or e.absActive==1 or e.absActive==true) and 1 or 0
  for _,side in ipairs({"L","R"}) do
    local delta=target[side]*.5-position[side]
    local travel=math.min(math.abs(delta),dt*.60)
    position[side]=position[side]+(delta<0 and -travel or travel)
    electrics.values["njkWindow"..side]=position[side]
    electrics.values["njkCrank"..side]=position[side]
    if panes[side] and not panes[side].disabled then
      panes[side].hidden=position[side]>=1
    end
  end
  timer=timer-dt
  if timer>0 then return end
  timer=.5
  local c=math.floor(obj:getEnvTemperature()-273.15+.5)
  electrics.values.njkTid_minus=c<0 and 1 or 0
  digits("temp",math.min(99,math.abs(c)))
  obj:queueGameEngineLua(string.format([[
    local tod=core_environment.getTimeOfDay()
    local car=be:getObjectByID(%d)
    if car and tod and tod.time then
      local minutes=math.floor(((tod.time+.5)%%1)*1440+.00001)%%1440
      car:queueLuaCommand(string.format("controller.getControllerSafe('njkCabin').clock(%%d,%%s,%%s,%%s)",minutes,tostring(tonumber(tod.day)),tostring(tonumber(tod.month)),tostring(tonumber(tod.year))))
    end]],obj:getID()))
end
M.init=reset
M.reset=reset
M.cycle=cycle
M.toggleFlap=function(name) local flap=flaps[name]; flap.target=1-flap.target end
M.cycleWipers=cycleWipers
M.pressHazard=pressHazard
M.clock=clock
M.updateGFX=updateGFX
return M
