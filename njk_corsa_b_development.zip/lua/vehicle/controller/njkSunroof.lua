local M={type='auxiliary'}
local state,tilt,slide=0,0,0
local function cycle() state=(state+1)%3 end
local function setState(value) state=math.max(0,math.min(2,value)) end
local function reset() state=0 tilt=0 slide=0 end
local function approach(a,b,dt) return a+math.max(-dt,math.min(dt,b-a)) end
local function updateGFX(dt)
 tilt=approach(tilt,state==1 and 1 or 0,dt*1.5)
 -- Lower the tilted pane before sliding it over the rear roof.
 slide=approach(slide,state==2 and (tilt<.02 and 1 or slide) or 0,dt*.65)
 electrics.values.njkSunroofActive=1
 electrics.values.njkSunroofState=state
 electrics.values.njkSunroofTilt=tilt
 electrics.values.njkSunroofSlide=slide
 electrics.values.njkRoofCrank=(tilt+2*slide)/2
 for _,p in pairs(v.data.props or {}) do
  if p.func=='njkSunroofActive' then
   p.rotation.x=math.rad(8)*tilt
   p.translation.y=.60*slide
   p.translation.z=.025*slide
  end
 end
end
M.init=reset M.reset=reset M.updateGFX=updateGFX M.cycle=cycle M.setState=setState
return M


