local M = {type="auxiliary"}
local phase, stroke, travel
local function reset()
  phase, stroke, travel = "closed", 0, 0
  electrics.values.njkHoodPull = 0
end
local function pull()
  if phase ~= "closed" then return end
  local lock = controller.getController("njk_hood_latch")
  if not lock or lock.getGroupState() ~= "attached" then return end
  phase, stroke = "pulling", .36
end
local function front()
  local lock = controller.getController("njk_hood_latch")
  local safety = controller.getController("njk_hood_safety")
  if phase == "released" and safety.getGroupState() == "attached" then
    safety.detachGroup()
    phase = "open"
  elseif phase == "open" then
    lock.tryAttachGroupImpulse()
  end
end
local function updateGFX(dt)
  stroke = math.max(0, stroke-dt)
  travel = math.max(0, math.min(1, travel + (stroke>0 and 8 or -5)*dt))
  electrics.values.njkHoodPull = travel
  local lock = controller.getController("njk_hood_latch")
  if phase == "pulling" and stroke <= .22 then
    lock.detachGroup()
    controller.getController("njk_hood_safety").tryAttachGroupImpulse()
    phase = "released"
  elseif phase == "open" and lock.getGroupState() == "attached" then
    phase = "closed"
  end
end
M.init=reset
M.reset=reset
M.pull=pull
M.front=front
M.updateGFX=updateGFX
return M
