local M = {type = "auxiliary"}
local metres = 0
local lastPosition
local lastTenths = -1
local masks = {63,6,91,79,102,109,125,7,127,111}
local function display(row, number, places)
  for place = 0, places - 1 do
    local mask = masks[number % 10 + 1]
    for segment = 0, 6 do
      electrics.values[string.format("njkOdo_%s_%d_%d",row,place,segment)] = math.floor(mask / 2^segment) % 2
    end
    number = math.floor(number / 10)
  end
end
-- Two alternating snapshots keep the preceding reading if a write is interrupted.
local prefix = "/settings/njk_corsa_b_odometer_"
local total, pending, elapsed, lastKm = 0, 0, 0, -1
local function latest()
  local best, slot = 0, 1
  for i = 0, 1 do
    local path = prefix..i..".json"
    local row = FS:fileExists(path) and jsonReadFile(path)
    if row and type(row.metres)=="number" and row.metres>=best then
      best, slot = row.metres, i
    end
  end
  return best, slot
end
local function save()
  if pending <= 0 then return end
  local saved, slot = latest()
  local value = math.max(saved,total) + pending
  local path = prefix..(1-slot)..".json"
  jsonWriteFile(path,{metres=value},false)
  local check = jsonReadFile(path)
  if check and math.abs(check.metres-value)<.001 then
    total, pending = value, 0
  end
end
local function reset()
  save()
  total = latest()
  elapsed, lastKm = 0, -1
  metres = 0
  lastPosition = nil
  lastTenths = -1
end
local function updateGFX(dt)
  local position = obj:getPosition()
  if lastPosition then
    local step = (position-lastPosition):length()
    if step > .0001 and step <= 2 + 150*dt then
      metres = metres + step
      pending = pending + step
    end
  end
  lastPosition = position
  elapsed = elapsed + dt
  local km = math.floor((total+pending)/1000)
  if elapsed >= 1 or km ~= lastKm then
    save()
    elapsed = 0
    km = math.floor((total+pending)/1000)
  end
  if km ~= lastKm then
    display("km",km,6)
    lastKm = km
  end
  local tenths = math.floor(metres/100)
  if tenths ~= lastTenths then
    display("trip",tenths,4)
    lastTenths = tenths
  end
end
M.init = reset
M.reset = reset
M.updateGFX = updateGFX
return M
